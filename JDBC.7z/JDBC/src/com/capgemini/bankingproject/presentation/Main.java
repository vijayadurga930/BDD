package com.capgemini.bankingproject.presentation;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.bankingproject.bean.Customers;
import com.capgemini.bankingproject.bean.Transaction;
import com.capgemini.bankingproject.exception.BankException;
import com.capgemini.bankingproject.service.BankServiceImpl;
import com.capgemini.bankingproject.service.IBankService;

public class Main {
	public static void main(String[] args) throws BankException {
			String continueChoice;
			boolean continueValue = false;

			Scanner scanner = null;
			do {

				System.out.println("*** welcome to Banking Application****1.Register/Create account/n"
						+ "2.View Balance/n3.Deposit/n4.Withdraw/n 5.Fund Transfer/n6.Print Transactions/n 7.exit");
			
				IBankService service = new BankServiceImpl();

				int choice = 0;
				boolean choiceFlag = false;

				do {
					scanner = new Scanner(System.in);
					System.out.println("Enter input:");
					try {
						choice = scanner.nextInt();
						choiceFlag = true;

						boolean nameFlag = false;

						String name = "";
						switch (choice) {

						case 1:
							do {
								scanner = new Scanner(System.in);
								System.out.println("Enter Customer name:");
								name = scanner.nextLine();
								service.custNameValidation(name);
								nameFlag = true;
							} while (!nameFlag);

							String mobile = "";
							boolean mobileFlag = false;
							do {
								scanner = new Scanner(System.in);
								System.out.println("Enter mobile :");
								try {
									mobile = scanner.nextLine();
									service.custMobValidation(mobile);
									mobileFlag = true;
								} catch (InputMismatchException e) {
									mobileFlag = false;
									System.err.println("Cost should be in digits");
								}
							} while (!mobileFlag);

							String email = "";
							boolean emailFlag = false;
							do {
								scanner = new Scanner(System.in);
								System.out.println("Enter email :");
								try {
									email = scanner.nextLine();
									service.custEmailValidation(email);
									emailFlag = true;
								} catch (InputMismatchException e) {
									emailFlag = false;
									System.err.println("Cost should be in digits");
								}
							} while (!emailFlag);

							System.out.println("Enter customer address:");
							String address = scanner.nextLine();

							Customers customer = new Customers(choice, name, mobile, email, address, choice, choice, null);

							try {
								
								double accountNo =service.addToCustomer(customer);
								System.out.println("Your accountNo is " + accountNo);
								
							/*
							 * List<Customers> addcust=service.insertCustomer(customer);
							 * System.out.println(addcust);
							 */
							} catch (BankException e) {
								System.err.println(e.getMessage());
							}

							break;
						case 2: {

							boolean custFlag = false;
							do {
								scanner = new Scanner(System.in);
								System.out.println("Enter custId to check balance:");
								try {
									int custId = scanner.nextInt();
									service.validateDestinationAccount(custId);

									service.showBalance(custId);
									break;
								} catch (BankException e) {
									custFlag = false;
									System.err.println(e.getMessage());
								}
							} while (!custFlag);

							break;
						}
						case 3: {

							boolean custFlag = false;
							do {
								scanner = new Scanner(System.in);
								System.out.println("Enter custId to deposit balance:");
								try {
									int custId = scanner.nextInt();
									service.validateDestinationAccount(custId);
									System.out.println("Enter amount to deposit");
									double amount = scanner.nextDouble();
									service.depositBalance(custId, amount);
									break;
								} catch (BankException e) {
									custFlag = false;
									System.err.println(e.getMessage());
								}
							} while (!custFlag);

							break;
						}

						case 4: {

							boolean custFlag = false;
							do {
								scanner = new Scanner(System.in);
								System.out.println("Enter custId to withdraw balance:");
								try {
									int custId = scanner.nextInt();
									service.validateDestinationAccount(custId);
									System.out.println("Enter amount to withdraw");
									double amount = scanner.nextDouble();
									service.withdrawBalance(custId, amount);
									break;
								} catch (BankException e) {
									custFlag = false;
									System.err.println(e.getMessage());
								}
							} while (!custFlag);
							break;
						}

						case 5: {

							boolean custFlag = false;
							do {
								scanner = new Scanner(System.in);
								System.out.println("Enter your customer Id to send money:");
								try {
									int sourceCustId = scanner.nextInt();
									service.validateDestinationAccount(sourceCustId);
									System.out.println("Enter custId to trasfer money:");
									int destinationCustId = scanner.nextInt();
									System.out.println("Enter your account number");
									long sourceAccNo = scanner.nextLong();
									System.out.println("Enter recipient account number");
									long destinationAccNo = scanner.nextLong();
									System.out.println("Enter amount to transfer");
									double amount = scanner.nextDouble();
									Transaction transaction = new Transaction();
									int transId= service.transferFunds(transaction, sourceCustId, destinationCustId);
									System.out.println("Succesfull transaction with transaction Id:"+transId);
									break;
								} catch (BankException e) {
									custFlag = false;
									System.err.println(e.getMessage());
								}
							} while (!custFlag);

							break;
						}

						case 6: {

							boolean transIdFlag = false;
							do {
								scanner = new Scanner(System.in);
								System.out.println("Enter transId to check transaction:");
								int transId = scanner.nextInt();
								service.validateTransactionId(transId);
								System.out.println(service.printTransactionDetails(transId));
								break;
							} while (!transIdFlag);

							break;
						}
					
						case 7:
							System.out.println("Thank u, visit again");
							System.exit(0);
							break;
						default:
							System.out.println("invalid input");
							choiceFlag = false;
							break;
						}

					} catch (InputMismatchException exception) {
						choiceFlag = false;
						System.err.println("input should contain only digits");
					}
				} while (!choiceFlag);

				do {
					scanner = new Scanner(System.in);
					System.out.println("do you want to continue again [yes/no]");
					continueChoice = scanner.nextLine();
					if (continueChoice.equalsIgnoreCase("yes")) {
						continueValue = true;
						break;
					} else if (continueChoice.equalsIgnoreCase("no")) {
						System.out.println("thank you");
						continueValue = false;
						break;
					} else {
						System.out.println("enter yes or no");
						continueValue = false;
						continue;
					}
				} while (!continueValue);

			} while (continueValue);
			scanner.close();

		}
}
