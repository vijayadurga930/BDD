package com.capgemini.bankingproject.service;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;


import com.capgemini.bankingproject.bean.Customers;
import com.capgemini.bankingproject.bean.Transaction;
import com.capgemini.bankingproject.dao.BankDaoImpl;
import com.capgemini.bankingproject.dao.IBankDao;
import com.capgemini.bankingproject.exception.BankException;

public class BankServiceImpl implements IBankService {

	IBankDao dao = new BankDaoImpl();
	
	@Override
	public void showBalance(int custId) throws BankException {
		dao.showBalance(custId);
	}

	@Override
	public int transferFunds(Transaction transaction, int sourceCustId, int destinationCustId) throws BankException {
		return dao.transferFunds(transaction,sourceCustId,destinationCustId );
	}

	@Override
	public void depositBalance(int custId, double amount) throws BankException {
		dao.depositBalance(custId,amount);
		
	}

	@Override
	public void withdrawBalance(int custId, double amount) throws BankException {
		dao.withdrawBalance(custId,amount);
		
	}

	@Override
	public Map<Integer, Transaction> printTransactionDetails(int transId) {
		return dao.printTransactionDetails(transId);  
	
		
		
	}

	@Override
	public long addToCustomer(Customers customer) throws BankException {
		return dao.addToCustomer(customer);
	}

	@Override
	public boolean custNameValidation(String name) throws BankException {
		boolean resultNameFlag=false;
		String nameRegex="^[A-Z]{1}[a-z]{5,}$";
		if(!Pattern.matches(nameRegex, name)) {
			resultNameFlag = false;
			throw new BankException("Customer Name should start with capital and lenght gt 5");
		}
		else {
			resultNameFlag = true;
		}
		return resultNameFlag;
	}
	

	@Override
	public boolean custMobValidation(String mobile) throws BankException {
		boolean resultMobFlag= false;
		String mobRegex ="[6,7,8,9]{1}[0-9]{9}$";
		if(!Pattern.matches(mobRegex, mobile)) {
			throw new BankException("Mobile no should start with 7,8,9 and should be 10 digit");
		}
		else {
			resultMobFlag= true;
		}
		return resultMobFlag;
	}

	@Override
	public boolean custEmailValidation(String email) throws BankException {
		boolean resultEmailFlag= false;
		String emailRegex="^[a-z]{5,}@[a-z]{3,}.com$";
		if(!Pattern.matches(emailRegex, email)){
			throw new BankException("Email should be in small case end with '.com' ");
		}
		else {
			resultEmailFlag= true;
		}
		return resultEmailFlag;
	}

	@Override
	public boolean validateDestinationAccount(int custId) throws BankException {
		boolean flag = false;
		Customers customer = BankDaoImpl.getCustomerList().get(custId);
		if(customer!= null) {
			flag = true;
		
		}
		else {
			flag= false;
			throw new BankException("Entered customer id is invalid");
		}
		return flag;
	}

	@Override
	public boolean validateTransactionId(int transId) throws BankException {
		boolean flag = false;
		Transaction transaction = BankDaoImpl.transactionList.get(transId);
		if(transaction!= null) {
			flag = true;
		
		}
		else {
			flag= false;
			throw new BankException("Entered transaction id is invalid");
		}
		return flag;
	
	}

	@Override
	public List<Customers> insertCustomer(Customers customer) throws BankException {
		return dao.insertCustomer(customer);
	}

	@Override
	public List<Customers> viewAll(Customers customer) throws BankException {
		return dao.viewAll(customer);
	}

}
