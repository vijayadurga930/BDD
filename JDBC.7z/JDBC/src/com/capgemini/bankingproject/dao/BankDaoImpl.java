package com.capgemini.bankingproject.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;


import com.capgemini.bankingproject.bean.Customers;
import com.capgemini.bankingproject.bean.Transaction;
import com.capgemini.bankingproject.exception.BankException;
import com.capgemini.bankingproject.utilitty.DBConnection;

public class BankDaoImpl implements IBankDao {

	public static Map<Integer, Customers> customerList = new HashMap<>();
	public static Map<Integer, Transaction> transactionList = new HashMap<>();
	
	PreparedStatement statement=null;
	ResultSet resultset=null;
	int row=-1;
	@Override
	public  List<Customers>insertCustomer(Customers customer) {
		int custId=0;
		try(Connection connection = DBConnection.getConnection();)
		{
			statement=connection.prepareStatement("select customerseq.NEXTVAL from dual");
			resultset=statement.executeQuery();
			if(resultset.next())
			custId=resultset.getInt(1);
			statement=connection.prepareStatement("insert into customer values(?,?,?,?,?) ");
			statement.setInt(1,custId);
			statement.setString(2,customer.getName());
			statement.setString(3,customer.getMobile());
			statement.setString(4,customer.getEmail());
			statement.setString(5,customer.getAddress());
			statement.setLong(6,customer.getAccountNo());
			statement.setDouble(7,customer.getBalance());
		
			row=statement.executeUpdate();
				}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return insertCustomer(customer);
	}
	@Override
	public long addToCustomer(Customers customer) throws BankException {
		int custId =(int) (Math.random()*10000);
		long accountNo = (long) (Math.random()*100000000L);
		customer.setCustId(custId);
		customer.setAccountNo(accountNo);
		getCustomerList().put(custId, customer);
		System.out.println("Your CustId is:"+ custId);
		return accountNo;
		
	}
	public static Map<Integer, Customers> getCustomerList() {
		return customerList;
	}
	public static void setCustomerList(Map<Integer, Customers> customerList) {
		BankDaoImpl.customerList = customerList;
	}
	public static Map<Integer,Transaction> gettransactionList() {
		return transactionList;
	}
	public static void settransactionList(Map<Integer, Transaction> transactionList) {
		BankDaoImpl.transactionList = transactionList;
	}


	@Override
	public void showBalance(int custId) throws BankException {
		Customers customer= BankDaoImpl.customerList.get(custId);
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == custId) {
				double balance = customer.getBalance();
				System.out.println("Your available balance is:"+balance);
			}
	}
		
	}

	@Override
	public int transferFunds(Transaction transaction, int sourceCustId, int destinationCustId) throws BankException {
		int transId= 0;
		double balanceSourceCust = 0.0;
		double balanceDestinationCust = 0.0;
		Customers customer1= BankDaoImpl.customerList.get(sourceCustId);
		Customers customer2= BankDaoImpl.customerList.get(destinationCustId);
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == sourceCustId) {
				balanceSourceCust =customer1.getBalance()- transaction.getAmount();
				if(balanceSourceCust<customer1.getBalance()) {
					transaction.setTransType("Debit");
				}
				else
					transaction.setTransType("Credit");
				customer1.setBalance(balanceSourceCust);
				balanceDestinationCust =customer1.getBalance()+transaction.getAmount();
				customer2.setBalance(balanceDestinationCust);
				break;
				
			}
			
		}
		
		transId = (int) (Math.random()*1000);
		Date transDate = new Date();
		transaction.setTransDate(transDate);
		transaction.setTransId(transId);
		transactionList.put(transId, transaction);
		return transId;
	}

	@Override
	public void depositBalance(int custId, double amount) throws BankException {
		Customers customer= BankDaoImpl.customerList.get(custId);
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == custId) {
				double balance = customer.getBalance()+amount;
				customer.setBalance(balance);
				System.out.println("Balance Succefully deposited!!Your available balance is:"+balance);
				
			}
			
	}
	}

	@Override
	public void withdrawBalance(int custId, double amount) throws BankException {
		Customers customer= BankDaoImpl.customerList.get(custId);
		Set keys= customerList.keySet();
		Iterator iterator =keys.iterator();
		while(iterator.hasNext()){
			int key = (int) iterator.next();
			if( key == custId) {
				double balance = customer.getBalance()-amount;
				customer.setBalance(balance);
				
				System.out.println("Transaction Successfull!!Your available balance is:"+balance);
			}
	}
		
	}

	@Override
	public Map<Integer, Transaction> printTransactionDetails(int transId) {
		return BankDaoImpl.gettransactionList();
		
	}
	@Override
	public List<Customers> viewAll(Customers customer) throws BankException {
	
			Customers customers=null;
			List<Customers> customerlist=new ArrayList<>();
			try(Connection connection=DBConnection.getConnection();)
			{
				statement=connection.prepareStatement("select * from customer");
		
				resultset=statement.executeQuery();
				while(resultset.next())
				{
					customers = new Customers();
					customers.setCustId(resultset.getInt("custId"));
					customer.setName(resultset.getString("name"));
					customer.setMobile(resultset.getString("mobile"));
					customer.setEmail(resultset.getString("email"));
					customer.setAddress(resultset.getString("Address"));
					customerlist.add(customer);
				}
					
			}catch(SQLException e) 
			{
				e.printStackTrace();
			}
			
			return customerlist;
			
			
		}
	}

	

	
	

