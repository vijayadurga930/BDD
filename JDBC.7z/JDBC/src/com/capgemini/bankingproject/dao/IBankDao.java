package com.capgemini.bankingproject.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.capgemini.bankingproject.bean.Customers;
import com.capgemini.bankingproject.bean.Transaction;
import com.capgemini.bankingproject.exception.BankException;

public interface IBankDao {

	
	public static Map<Integer, Customers> customerList = new HashMap<>();
	long addToCustomer(Customers customer)throws BankException;
	void showBalance(int custId)throws BankException;
	int transferFunds(Transaction transaction,int sourceCustId,int destinationCustId) throws BankException;
	void depositBalance(int custId,double amount)throws BankException;
	void withdrawBalance(int custId, double amount)throws BankException;
	public Map<Integer, Transaction> printTransactionDetails(int transId);
	List<Customers> insertCustomer(Customers customer)throws BankException;
	List<Customers> viewAll(Customers customer)throws BankException;

}
