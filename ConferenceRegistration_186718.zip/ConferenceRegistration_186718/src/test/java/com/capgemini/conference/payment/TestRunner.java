package com.capgemini.conference.payment;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty"},features= {"C:/BDD777/ConferenceRegistration_186718/src/test/resources/PaymentDetails.feature"})
public class TestRunner {

}
