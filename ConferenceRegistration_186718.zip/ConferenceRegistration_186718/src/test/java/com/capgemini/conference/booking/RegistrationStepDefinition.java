package com.capgemini.conference.booking;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.conference.bean.RegistrationPageFactory;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition {
	private WebDriver driver;
	private RegistrationPageFactory pageFactory;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:/BDD777/ConferenceRegistration_186718/Drivers/chromedriver.exe");
		driver= new ChromeDriver();
	}
	
	@Given("^user is on 'Registration' page$")
	public void user_is_on_Registration_page() throws Throwable {
	    driver.get("C:/BDD777/ConferenceRegistration_186718/ConferenceRegistartion.html");
	    pageFactory = new RegistrationPageFactory(driver);
	}

	@Then("^'Verifying the title of page'$")
	public void verifying_the_title_of_page() throws Throwable {
	    String expectedMessage = "Conference Registration";
	    String actualMessage = driver.getTitle();
	    Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}

	@Then("^'Verifying the Text on the page'$")
	public void verifying_the_Text_on_the_page() throws Throwable {
		String bodyText = driver.findElement(By.tagName("body")).getText();
		Assert.assertTrue("Text not found!", bodyText.contains("Conference Registration"));
		driver.close();
	}

	@When("^user clicks 'Next' button without entering any data in first name$")
	public void user_clicks_Next_button_without_entering_any_data_in_first_name() throws Throwable {
		pageFactory.setFirstname("");
		pageFactory.setNextButton();
	}

	@Then("^alert box displays 'Please fill the First Name'$")
	public void alert_box_displays_Please_fill_the_First_Name() throws Throwable {
		String expectedMessage="Please fill the First Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user clicks 'Next' button without entering any data in last name$")
	public void user_clicks_Next_button_without_entering_any_data_in_last_name() throws Throwable {
	    pageFactory.setFirstname("sravani");
	    pageFactory.setLastName("");
	    pageFactory.setNextButton();
	}

	@Then("^alert box displays 'Please fill the Last Name'$")
	public void alert_box_displays_Please_fill_the_Last_Name() throws Throwable {
		String expectedMessage="Please fill the Last Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters incorrect email format$")
	public void user_enters_incorrect_email_format() throws Throwable {
	   pageFactory.setFirstname("sravani");
	   pageFactory.setLastName("reddy");
	   pageFactory.setEmail("");
	   pageFactory.setNextButton();
	}

	@Then("^alert box displays 'Please fill the Email'$")
	public void alert_box_displays_Please_fill_the_Email() throws Throwable {
		String expectedMessage="Please fill the Email";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user clicks 'Next' button without entering contact number starting with (\\d+),(\\d+) or (\\d+)$")
	public void user_clicks_Next_button_without_entering_contact_number_starting_with_or(int arg1, int arg2, int arg3) throws Throwable {
		pageFactory.setFirstname("sravani");
		pageFactory.setLastName("reddy");
		pageFactory.setEmail("sravanireddy6197@gmail.com");
		pageFactory.setContactNo("");
		pageFactory.setNextButton();
	}

	@Then("^alert box displays 'Please enter valid Contact no\\.'$")
	public void alert_box_displays_Please_enter_valid_Contact_no() throws Throwable {
		String expectedMessage="Please enter valid Contact no.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user clicks 'Next' button without selecting number of people attending$")
	public void user_clicks_Next_button_without_selecting_number_of_people_attending() throws Throwable {
		pageFactory.setFirstname("sravani");
		pageFactory.setLastName("reddy");
		pageFactory.setEmail("sravanireddy6197@gmail.com");
		pageFactory.setContactNo("9154102973");
		pageFactory.setPersonCount(0);
		pageFactory.setNextButton();
	}

	@Then("^alert box displays 'Number of people attending'$")
	public void alert_box_displays_Number_of_people_attending() throws Throwable {
		String expectedMessage="Number of people attending";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user clicks 'Next' button without entering any data in the text box$")
	public void user_clicks_Next_button_without_entering_any_data_in_the_text_box() throws Throwable {
		pageFactory.setFirstname("sravani");
		pageFactory.setLastName("reddy");
		pageFactory.setEmail("sravanireddy6197@gmail.com");
		pageFactory.setContactNo("9154102973");
		pageFactory.setPersonCount(2);
		pageFactory.setAddress("");
		pageFactory.setArea("");
		pageFactory.setNextButton();
	}

	@Then("^alert box displays 'Please fill the Building & Room No\\.'$")
	public void alert_box_displays_Please_fill_the_Building_Room_No() throws Throwable {
		String expectedMessage="Please fill the Building & Room No.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	
	@Then("^alert box displays 'Please fill the Area name'$")
	public void alert_box_displays_Please_fill_the_Area_name() throws Throwable {
		String expectedMessage="Please fill the Area name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user clicks 'Next' button without selecting any city$")
	public void user_clicks_Next_button_without_selecting_any_city() throws Throwable {
		pageFactory.setFirstname("sravani");
		pageFactory.setLastName("reddy");
		pageFactory.setEmail("sravanireddy6197@gmail.com");
		pageFactory.setContactNo("9154102973");
		pageFactory.setPersonCount(2);
		pageFactory.setAddress("Atp, Room no.1");
		pageFactory.setArea("IGate");
		pageFactory.setCity("");
		pageFactory.setNextButton();
	}

	@Then("^alert box displays 'Please select city'$")
	public void alert_box_displays_Please_select_city() throws Throwable {
		String expectedMessage="Please select city";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user clicks 'Next' button without selecting any state$")
	public void user_clicks_Next_button_without_selecting_any_state() throws Throwable {
		pageFactory.setFirstname("sravani");
		pageFactory.setLastName("reddy");
		pageFactory.setEmail("sravanireddy6197@gmail.com");
		pageFactory.setContactNo("9154102973");
		pageFactory.setPersonCount(2);
		pageFactory.setAddress("Atp, Room no.1");
		pageFactory.setArea("IGate");
		pageFactory.setCity("Banglore");
		pageFactory.setState("");
		pageFactory.setNextButton();
	}

	@Then("^alert box displays 'Please select state'$")
	public void alert_box_displays_Please_select_state() throws Throwable {
		String expectedMessage="Please select state";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user clicks 'Next' button without selecting Conference full-Access\\(member\\) or Conference full-Access\\(non-member\\)$")
	public void user_clicks_Next_button_without_selecting_Conference_full_Access_member_or_Conference_full_Access_non_member() throws Throwable {
		pageFactory.setFirstname("sravani");
		pageFactory.setLastName("reddy");
		pageFactory.setEmail("sravanireddy6197@gmail.com");
		pageFactory.setContactNo("9154102973");
		pageFactory.setPersonCount(2);
		pageFactory.setAddress("Atp, Room no.1");
		pageFactory.setArea("IGate");
		pageFactory.setCity("Banglore");
		pageFactory.setState("Karnataka");
		pageFactory.setMemberStatus("");
		pageFactory.setNextButton();
	}

	@Then("^alert box displays 'Please Select Membership status'$")
	public void alert_box_displays_Please_Select_Membership_status() throws Throwable {
		String expectedMessage="Please Select Membership status";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user clicks 'Next' button$")
	public void user_clicks_Next_button() throws Throwable {
		pageFactory.setFirstname("sravani");
		pageFactory.setLastName("reddy");
		pageFactory.setEmail("sravanireddy6197@gmail.com");
		pageFactory.setContactNo("9154102973");
		pageFactory.setPersonCount(2);
		pageFactory.setAddress("Atp, Room no.1");
		pageFactory.setArea("IGate");
		pageFactory.setCity("Banglore");
		pageFactory.setState("Karnataka");
		pageFactory.setMemberStatus("Conference full-Access(member)");
		pageFactory.setNextButton();
	}

	@Then("^alert box displays 'Conference details are validated'$")
	public void alert_box_displays_Conference_details_are_validated() throws Throwable {
		String expectedMessage="Conference details are validated";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
	}


}
