package com.capgemini.conference.booking;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty"},features= {"C:/BDD777/ConferenceRegistration_186718/src/test/resources/registration.feature"})
public class TestRunner {

}
