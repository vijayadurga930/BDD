package com.capgemini.conference.payment;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.conference.bean.PaymentPageFactory;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PaymentStepDefinition {

	private WebDriver driver;
	private PaymentPageFactory paymentPageFactory;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","C:/BDD777/ConferenceRegistration_186718/Drivers/chromedriver.exe");
		driver= new ChromeDriver();
	}
	
	@Given("^user is on 'Payment Details' page$")
	public void user_is_on_Payment_Details_page() throws Throwable {
	    driver.get("C:/BDD777/ConferenceRegistration_186718/PaymentDetails.html");
	    paymentPageFactory=new PaymentPageFactory(driver);
	}

	@Then("^'Verifying the title of page'$")
	public void verifying_the_title_of_page() throws Throwable {
		String expectedMessage = "Personal Details";
	    String actualMessage = driver.getTitle();
	    Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}

	@Then("^'Verifying the Text on the page'$")
	public void verifying_the_Text_on_the_page() throws Throwable {
		String bodyText = driver.findElement(By.tagName("body")).getText();
		Assert.assertTrue("Text not found!", bodyText.contains("Personal Details"));
		driver.close();
	}

	@When("^user clicks 'Make Payment' button without entering any data in the text box$")
	public void user_clicks_Make_Payment_button_without_entering_any_data_in_the_text_box() throws Throwable {
	    paymentPageFactory.setCardHolderName("");
	    paymentPageFactory.setPaymentButton();
	}

	@Then("^alert box displays 'Please fill the Card holder name'$")
	public void alert_box_displays_Please_fill_the_Card_holder_name() throws Throwable {
		String expectedMessage="Please fill the Card holder name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	
	@When("^user clicks 'Make Payment' button without entering any number data in the text box$")
	public void user_clicks_Make_Payment_button_without_entering_any_number_data_in_the_text_box() throws Throwable {
		paymentPageFactory.setCardHolderName("Sravani Reddy");
		paymentPageFactory.setDebitCardNo("");
	    paymentPageFactory.setPaymentButton();
	}

	@Then("^alert box displays 'Please fill the Debit card Number'$")
	public void alert_box_displays_Please_fill_the_Debit_card_Number() throws Throwable {
		String expectedMessage="Please fill the Debit card Number";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user clicks 'Make Payment' button without entering any month data in the text box$")
	public void user_clicks_Make_Payment_button_without_entering_any_month_data_in_the_text_box() throws Throwable {
		paymentPageFactory.setCardHolderName("Sravani Reddy");
		paymentPageFactory.setDebitCardNo("22223333");
		paymentPageFactory.setExpirationMonth("");
	    paymentPageFactory.setPaymentButton();
	}
	@Then("^alert box displays 'Please fill expiration month'$")
	public void alert_box_displays_Please_fill_expiration_month() throws Throwable {
		String expectedMessage="Please fill expiration month";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user clicks 'Make Payment' button without entering any year data in the text box$")
	public void user_clicks_Make_Payment_button_without_entering_any_year_data_in_the_text_box() throws Throwable {
		paymentPageFactory.setCardHolderName("Sravani Reddy");
		paymentPageFactory.setDebitCardNo("22223333");
		paymentPageFactory.setExpirationMonth("06");
		paymentPageFactory.setYear("");
	    paymentPageFactory.setPaymentButton();
	}

	@Then("^alert box displays 'Please fill expiration year'$")
	public void alert_box_displays_Please_fill_expiration_year() throws Throwable {
		String expectedMessage="Please fill expiration year";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user clicks 'Make Payment' button$")
	public void user_clicks_Make_Payment_button() throws Throwable {
		paymentPageFactory.setCardHolderName("Sravani Reddy");
		paymentPageFactory.setDebitCardNo("22223333");
		paymentPageFactory.setExpirationMonth("06");
		paymentPageFactory.setYear("2024");
		paymentPageFactory.setCvv("137");
	    paymentPageFactory.setPaymentButton();
	}

	@Then("^alert box displays 'Conference Room Booking successfully done!!!'$")
	public void alert_box_displays_Conference_Room_Booking_successfully_done() throws Throwable {
		String expectedMessage="Conference Room Booking successfully done!!!";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
	}


}