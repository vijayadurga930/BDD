package com.capgemini.conference.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class RegistrationPageFactory {
	WebDriver driver;
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement firstname;
	
	@FindBy(how=How.ID, using="#")
	@CacheLookup
	WebElement nextButton;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement lastname;
	
	@FindBy(name="Email")
	@CacheLookup
	WebElement email;
	
	@FindBy(name="Phone")
	@CacheLookup
	WebElement contactNo;
	
	@FindBy(how=How.NAME, using="size")
	@CacheLookup
	int personCount;
	
	@FindBy(name="Address")
	@CacheLookup
	WebElement address;
	
	@FindBy(name="Address2")
	@CacheLookup
	WebElement area;
	
	@FindBy(how=How.NAME, using="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(how=How.NAME, using="state")
	@CacheLookup
	WebElement state;
	
	@FindBy(name="memberStatus")
	@CacheLookup
	WebElement memberStatus;

	public RegistrationPageFactory(WebDriver driver2) {
		this.driver=driver2;
		PageFactory.initElements(driver, this);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname.sendKeys(firstname);;
	}

	public WebElement getNextButton() {
		return nextButton;
	}

	public void setNextButton() {
		this.nextButton.click();;
	}

	public WebElement getLastname() {
		return lastname;
	}
	public void setLastName(String lastName) {
		this.lastname.sendKeys(lastName);
	}
	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo.sendKeys(contactNo);
	}

	public int getPersonCount() {
		return personCount;
	}

	public void setPersonCount(int personCount) {
		this.personCount = personCount;
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);;
	}

	public WebElement getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area.sendKeys(area);;
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getState() {
		return state;
	}

	public void setState(String state) {
		this.state.sendKeys(state);;
	}

	public WebElement getMemberStatus() {
		return memberStatus;
	}

	public void setMemberStatus(String memberStatus) {
		this.memberStatus.sendKeys(memberStatus);;
	}
	
	
	
}
