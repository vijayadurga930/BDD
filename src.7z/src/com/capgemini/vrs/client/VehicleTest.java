package com.capgemini.vrs.client;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "C:/Users/vijsimha/Downloads/VehicleregistartionBDDProject/Feature/vehicle.feature", glue = { "com.capgemini.vrs.stepdefinition" })
public class VehicleTest {

}
