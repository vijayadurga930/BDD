package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.bean.Banking;
import com.cg.bean.Trans_info;
import com.cg.exception.BankException;

public class BankdaoImpl implements IBankdao{

	@Override
	public Banking addAccount(Banking bean) {
		Connection conn = DBConnect.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("insert into Bank values (?,?,?,?,?)");
			p.setString(1, bean.getCustomer_name());
			p.setString(2, bean.getContact_number());
			p.setDouble(3, bean.getAmount());
			p.setString(4, bean.getCity());
			p.setInt(5, bean.getAccount_id());
	        p.executeUpdate();
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from bank");
			if (rs.next())
				bean.setAccount_id(rs.getInt(5));

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return bean;
	}
	
	

	@Override
	public Banking getAccountBalance(int account_id) {
		Banking b = new Banking();
	
		Connection conn = DBConnect.getConnection();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from Bank where Acoount_id =" + account_id);
			while (rs.next()) {
			
				b.setCustomer_name(rs.getString(1));
				b.setAmount(rs.getDouble(3));
				b.setAccount_id(rs.getInt(5));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return b;
	}
	

@Override
public Banking deposit(int account_id, double amount) {
		Banking b = new Banking();
		Connection conn = DBConnect.getConnection();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from Bank where Acoount_id =" + account_id);
			while (rs.next()) {
				b.setAccount_id(rs.getInt(5));
				b.setCustomer_name(rs.getString(1));
				b.setAmount(rs.getDouble(3) + amount);
			}
			double updatedAmount= b.getAmount();
			PreparedStatement p = conn.prepareStatement(
					"update Bank set amount=" + updatedAmount+ " where Acoount_id  =" + account_id);
			p.executeUpdate();

			p = conn.prepareStatement("insert into Trans_info values(?,?,?,?)");
			p.setInt(1, account_id);
			p.setDate(2, new Date(System.currentTimeMillis()));
			p.setDouble(3, amount);
			p.setString(4, "Deposited");
			p.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return b;
	}
	

	@Override
	public Banking withdraw(int account_id, double amount) {
		Banking b = new Banking();
		Connection conn = DBConnect.getConnection();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from Bank where Acoount_id =" + account_id);
			while (rs.next()) {
				b.setAccount_id(rs.getInt(5));
				b.setCustomer_name(rs.getString(1));
				b.setAmount(rs.getDouble(3) - amount);
			}
			double updatedAmount= b.getAmount();
		
PreparedStatement p = conn.prepareStatement("update Bank set amount=" +  updatedAmount + " where Acoount_id  =" + account_id);
			p.executeUpdate();
			p = conn.prepareStatement("insert into Trans_info values(?,?,?,?)");
			p.setInt(1, account_id);
			p.setDate(2, new Date(System.currentTimeMillis()));
			p.setDouble(3, amount);
			p.setString(4, "WithDraw");
			p.executeUpdate();
		

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return b;
	}

	@Override
	public Banking fundTransfer(int account_id1, int account_id2, double amount) {
		Banking b1 = new Banking();
		Connection conn = DBConnect.getConnection();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from Bank where Acoount_id =" + account_id1);
			while (rs.next()) {
				b1.setAccount_id(rs.getInt(5));
				b1.setCustomer_name(rs.getString(1));
				b1.setAmount(rs.getDouble(3) - amount);
				
			}
			double updatedAmount= b1.getAmount();
			PreparedStatement p = conn.prepareStatement(
					"update Bank set amount=" +  updatedAmount + " where Acoount_id  =" + account_id1);
			p.executeUpdate();
			p = conn.prepareStatement("insert into Trans_info values(?,?,?,?)");
			p.setInt(1, account_id1);
			p.setDate(2, new Date(System.currentTimeMillis()));
			p.setDouble(3, amount);
			p.setString(4, "Tran " + account_id2+" ");
			p.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Banking b2 = new Banking();

		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from Bank where Acoount_id =" + account_id2);
			while (rs.next()) {
				b2.setAccount_id(rs.getInt(1));
				b2.setCustomer_name(rs.getString(2));
				b2.setAmount(rs.getDouble(4) + amount);
			}
PreparedStatement p = conn.prepareStatement("update Bank set amount=" + b2.getAmount() + " where Acoount_id  =" + account_id2);
			p.executeUpdate();
			p = conn.prepareStatement("insert into Trans_info values(?,?,?,?)");
			p.setInt(1, account_id2);
			p.setDate(2, new Date(System.currentTimeMillis()));
			p.setDouble(3, amount);
			p.setString(4, "Funds Transfered From " + account_id1);
			p.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return b1;
	}

	@Override
	public ArrayList printDetails(int account_id) {
		ArrayList<String> a = new ArrayList<String>();
		Connection conn = DBConnect.getConnection();
		String str = "";
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery("select * from Trans_info where Account_id =" + account_id);
			while (rs.next()) {
				//str = String.valueOf(rs.getInt(1))+"\t\t";
				str+=rs.getInt(1)+"\t\t";
				str+=rs.getDate(2)+"\t\t";
				str+=rs.getDouble(3)+"\t\t";
				str+=rs.getString(4);
				a.add(str);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return a;

	}



	public boolean insertToTransaction(Banking bank, int transactId) throws SQLException {
		Trans_info t=new Trans_info();
		
		Banking b2 = new Banking();
		  try (Connection connection = DBConnect.getConnection();)	{
		  Statement statement = connection.createStatement();
         statement = connection.prepareStatement("insert into Trans_info values (?,?,?)");
         ResultSet rs = statement.executeQuery("select * from Trans_info where Account_id =" +transactId);
         t.setAccount_id(rs.getInt(1));
		  t.setDate1(new Date(System.currentTimeMillis()));
	     t.setAmount(rs.getDouble(3) + b2.getAmount());  
	       return true;
	        } catch (SQLException e) {
	            System.out.println(e.getMessage());
	        }
		
		
		
		
		return false;

		
	}



	
}


	


