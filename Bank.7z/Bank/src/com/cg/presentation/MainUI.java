package com.cg.presentation;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.bean.Banking;
import com.cg.service.BankServiceImpl;

public class MainUI {
public static void main(String[] args) {
	BankServiceImpl bankservice = new BankServiceImpl();
	Scanner scanner = new Scanner(System.in);
	int choice;
	do {
		System.out.println("******Welcome to My Bank Services********");
		
System.out.println(" 1.Create Account\n 2.Display Balance\n 3.Deposit Amount\n 4.Withdraw Amount\n 5.FundsTransfer\n 6.Display Transaction Details\n 7.Exit");
		System.out.print("Enter Your Choice: ");
		choice = scanner.nextInt();
		switch (choice) {
		case 1:
			int account_id=0;
			System.out.print("Enter Name:");
			String name = scanner.next();
			System.out.print("Enter Mobile Number: ");
			String mobileno = scanner.next();
			System.out.print("Enter Initial Amount: ");
			double amount = scanner.nextDouble();
			System.out.print("Enter City: ");
			String city = scanner.next();
			System.out.print("Enter State: ");
			String state = scanner.next();
			 
			Banking bean = new Banking(account_id, name, mobileno, amount, city);
			int accountId=bankservice.getaccountId(bean);
			Banking b = bankservice .addAccount(bean);
			
			System.out.println("------------------------------------------------------------");
			System.out.println("Thank you " + name + " Your Account is created Successfully");
			int account_Id=bankservice.getaccountId(bean );
			System.out.println("Your Account Id " + b.getAccount_id());
			bean.setAccount_id(account_Id);
			break;
		
		case 2:
			System.out.print("Enter Account Id: ");
			 account_Id = scanner.nextInt();
			 Banking b1=new Banking();
			b = bankservice .getAccountBalance(account_Id);
		
System.out.println("Hello,Hi " + b1.getCustomer_name() + "\n Your Current Account Balance is " + b.getAmount());
			
			Banking bank = null;
			int transactId=0;
			int c=bankservice.transactionId(bank, transactId);
			System.out.println(c);
			break;
		
		case 3:
			System.out.print("Enter Account Id: ");
			account_id = scanner.nextInt();
			System.out.print("Enter Amount to be Deposited: ");
			amount = scanner.nextDouble();
			b = bankservice .deposit(account_id, amount);
			System.out.println("------------------------------------------------------------------------");
			System.out.println("Hello " + b.getCustomer_name() + " Your Amount is Deposited Succesfully");
			System.out.println("Your Current Account Balence is " + b.getAmount());
			break;
		
		case 4:
			System.out.print("Enter Account Id: ");
			account_id = scanner.nextInt();
			System.out.print("Enter Amount to be WithDrawn: ");
			amount = scanner.nextDouble();
			b = bankservice .withdraw(account_id, amount);
			System.out.println("------------------------------------------------------------------------");
			System.out.println("Hello " + b.getCustomer_name() + " Your Amount is Withdrawn Succesfully");
			System.out.println("Your Current Account Balance is " + b.getAmount());
			break;
			
		case 5:
			System.out.print("Enter Your Account Id: ");
		int account_id1 = scanner.nextInt();
		System.out.print("Enter Account Id of person you want to transfer Amount: ");
		int account_id2 = scanner.nextInt();
		System.out.print("Enter Amount to be Transfered: ");
		amount = scanner.nextDouble();
		b =bankservice .fundTransfer(account_id1, account_id2, amount);
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println("Hello " + b.getCustomer_name() + " Your Amount is Transferred Succesfully\n");
		System.out.println("Your Current Account Balance is " + b.getAmount());

			break;
		
		case 6:
			System.out.print("Enter Your Account Number to Know Your Transaction Details:");
			account_id = scanner.nextInt();
			ArrayList a = bankservice .printDetails(account_id);
			System.out.println(" Transaction_Id  \t Account_Id    Transaction_Date     Transaction_Amount Transaction_Type");
			
			for(Object i:a)
			System.out.println(i+"\n");
		
			break;
		
		case 7:
		
			System.out.println("Thanks For Using Our Bank Services And Visit Again....!!!");
			System.out.println("Please select from 1-6 options only");
			System.exit(0);
			break;

		}

	} while (choice != 7);
	
}

}

