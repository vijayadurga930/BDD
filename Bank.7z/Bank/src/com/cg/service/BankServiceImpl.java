package com.cg.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.bean.Banking;
import com.cg.dao.BankdaoImpl;

public class BankServiceImpl implements IBankService{
	BankdaoImpl bankdao = new BankdaoImpl();
	@Override
	public Banking addAccount(Banking bean) {
		
		return bankdao.addAccount(bean);
	}

	@Override
	public Banking getAccountBalance(int account_id) {
		
		return bankdao.getAccountBalance(account_id);
	}

	@Override
	public Banking deposit(int account_id, double amount) {
		
		return bankdao.deposit(account_id, amount);
	}

	@Override
	public Banking withdraw(int account_id, double amount) {
		
		return bankdao.withdraw(account_id, amount);
	}

	@Override
	public Banking fundTransfer(int account_id1, int account_id2, double amount) {
		// TODO Auto-generated method stub
		return bankdao.fundTransfer(account_id1, account_id2, amount);
	}

	@Override
	public ArrayList printDetails(int account_id) {
		// TODO Auto-generated method stub
		return bankdao.printDetails(account_id);
	}

	@Override
	public int transactionId(Banking bank, int transactId) {
		transactId = (int) (Math.random() *1000);
        bank.setTransact_Id(transactId);
     
		boolean status=true;
		try {
			status = bankdao.insertToTransaction(bank, transactId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        if (status) {
            return transactId;
	}
		return transactId;
	
}

	@Override
	public int getaccountId(Banking bank) {
		int id=(int) (Math.random()*1000);
		bank.setAccount_id(id);
			return id;
	}

	

}

