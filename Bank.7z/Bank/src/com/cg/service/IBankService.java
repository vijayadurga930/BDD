package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.Banking;

public interface IBankService {

	Banking addAccount(Banking bean);
	Banking getAccountBalance(int account_id);
	Banking deposit(int account_id, double amount);
	Banking withdraw(int account_id, double amount);
	Banking fundTransfer(int account_id1,int account_id2, double amount);
	ArrayList printDetails(int account_id);
	public int transactionId(Banking bank, int transactId);
	public int getaccountId(Banking bank);
}
