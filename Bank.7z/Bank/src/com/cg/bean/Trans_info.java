package com.cg.bean;

import java.util.Date;

public class Trans_info {
	private int  account_id;
	 private  Date Date1;
	 private double amount;
	public int getAccount_id() {
		return account_id;
	}
	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}
	public Date getDate1() {
		return Date1;
	}
	public void setDate1(Date date1) {
		Date1 = date1;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Trans_info [account_id=" + account_id + ", Date1=" + Date1 + ", amount=" + amount + "]";
	}
	public Trans_info() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Trans_info(int account_id, Date date1, double amount) {
		super();
		this.account_id = account_id;
		Date1 = date1;
		this.amount = amount;
	}

}
