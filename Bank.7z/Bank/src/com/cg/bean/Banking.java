package com.cg.bean;

import java.util.Date;

public class Banking {
	private int account_id;
	private String customer_name;
	private String contact_number;
	private double amount;
	private String city;
	private int transact_Id;
	private Date Date1;


	
	

	public int getTransact_Id() {
		return transact_Id;
	}

	public void setTransact_Id(int transact_Id) {
		this.transact_Id = transact_Id;
	}

	public Date getDate1() {
		return Date1;
	}

	public void setDate1(Date date1) {
		Date1 = date1;
	}

	public int getAccount_id() {
		return account_id;
	}

	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public String getContact_number() {
		return contact_number;
	}

	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Banking(int account_id, String customer_name, String contact_number, double amount, String city) {
		super();
		this.account_id = account_id;
		this.customer_name = customer_name;
		this.contact_number = contact_number;
		this.amount = amount;
		this.city = city;
	}
	@Override
	public String toString() {
		return "Banking [account_id=" + account_id + ", customer_name=" + customer_name + ", contact_number="
				+ contact_number + ", amount=" + amount + ", city=" + city + "]";
	}

	public Banking() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
